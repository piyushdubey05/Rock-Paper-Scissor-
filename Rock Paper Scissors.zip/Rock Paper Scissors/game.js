let userscored=0;
let compscored=0;

const choices = document.querySelectorAll(".choice");
const btn = document.querySelector(".btn")

const userscoredpara =document.querySelector("#us")
const compuscoredpara =document.querySelector("#cs")

const gencompchoice=() => {
    const options=["rock","paper","scissors"];
    const randIDX=Math.floor(Math.random()*3)
    return options[randIDX]
}
const drawGame =() =>{
    msg.innerText="game was draw"
    msg.style.backgroundColor="black";

}
const showwinner =(userwin , userchoice ,computerchoice) =>{
    if (userwin) {
        userscored++;
        userscoredpara.innerText=userscored;
        msg.innerText='you win your'
        msg.style.backgroundColor="blue";
    }
    else{
        compscored++
        compuscoredpara.innerText=compscored
        msg.innerText="you lose"
        msg.style.backgroundColor="orange";

    }
}
const playgame=(userchoice) =>{
     console.log("user choice ",userchoice)
     const computerchoice =gencompchoice();
     console.log("comp choice", computerchoice)
     if (userchoice === computerchoice) {
        drawGame();
     }
     else{
        let userwin=true;
        if (userchoice === "rock") {
            userwin = computerchoice === "paper" ? false :true;
        }
        else if(userchoice === "paper"){
           userwin = computerchoice === "scissors" ? false: true;
        }
        else{
            userwin=computerchoice === "rock" ? false : true;
        }
        showwinner(userwin , userchoice , computerchoice);
     }
}
choices.forEach((choice) =>{
    choice.addEventListener("click",() => {
        const userchoice=choice.getAttribute("id")
            playgame(userchoice) });
});


